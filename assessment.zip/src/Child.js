const Child = ({ userData, handleGetDetails, postData }) => {
  return (
    <>
      <h1>Fetch Data</h1>
      <ul>
        {userData && userData.length > 0 && userData.map((item, index) => {
          return (
            <li key={index}>
              <span>
                {item.id} {item.title}
              </span>
              <button onClick={(e)=>handleGetDetails(item.id)}>Get Details</button>
              {
                postData && postData.length > 0 && postData.map((postItem,index)=>{
                    const displayPara = postItem.id === item.id ? 'displayPara' : '';
                    return <p key={index} className={displayPara}>{postItem.body}</p>
                })
              }
            </li>
          );
        })}
      </ul>
    </>
  );
};
export default Child;
