import React, { useState, useEffect, useCallback } from "react";
import Child from "./Child";
import "./App.css";

const baseUrl = "https://jsonplaceholder.typicode.com/posts";

function App() {
  const [userData, setUserData] = useState([]);
  const [postData, setPostData] = useState([]);
  const fetchData = async () => {
    try {
      const response = await fetch(baseUrl);
      if (response.ok) {
        const data = await response.json();
        setUserData(data);
      } else {
        alert("Somthing went wrong");
      }
    } catch (error) {
      alert(`Fetch Error is ${error}`);
    }
  };

  const handleGetDetails = useCallback(async(e) => {
    const data = {
      id: e,
    };
    const queryString = Object.keys(data)
      .map(
        (key) => encodeURIComponent(key) + "=" + encodeURIComponent(data[key])
      )
      .join("&");
    const url = `${baseUrl}?${queryString}`;
    try {
      const response = await fetch(url);
      if (response.ok) {
        const postDatas = await response.json();
        setPostData(postDatas);
      } else {
        alert("Somthing went wrongs");
      }
    } catch (error) {
      alert(`Fetch Error is ${error}`);
    }
  });
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <div className="App">
      <Child userData={userData} handleGetDetails={handleGetDetails} postData={postData}/>
    </div>
  );
}

export default App;
